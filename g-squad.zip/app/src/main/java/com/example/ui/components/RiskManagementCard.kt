package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserAccount
import com.example.ui.theme.GsquadOnYellow
import com.example.ui.theme.GsquadYellow
import com.example.ui.theme.LightBorder
import com.example.ui.theme.LightSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TradeGreen
import com.example.ui.theme.TradeRed
import java.util.Locale

@Composable
fun RiskManagementCard(
  user: UserAccount?,
  onSaveRisk: (stake: Double, tp: Double, sl: Double) -> Unit,
  modifier: Modifier = Modifier
) {
  var stakeText by remember(user?.stakeAmount) {
    mutableStateOf(String.format(Locale.US, "%.0f", user?.stakeAmount ?: 5.0))
  }
  var tpText by remember(user?.targetProfit) {
    mutableStateOf(String.format(Locale.US, "%.0f", user?.targetProfit ?: 50.0))
  }
  var slText by remember(user?.targetLoss) {
    mutableStateOf(String.format(Locale.US, "%.0f", user?.targetLoss ?: 25.0))
  }

  val isRunning = user?.isBotRunning == true

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("risk_management_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = LightSurface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, LightBorder, RoundedCornerShape(16.dp))
        .padding(16.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Shield,
            contentDescription = null,
            tint = GsquadYellow,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Risk Management",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = TextPrimary
          )
        }

        if (isRunning) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFFFFF3D4))
              .padding(horizontal = 8.dp, vertical = 2.dp)
          ) {
            Text(
              text = "Locked while running",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF7A4F00)
            )
          }
        }
      }

      Text(
        text = "Set your trade stake, target profit, and stop loss limit",
        fontSize = 12.sp,
        color = TextSecondary,
        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
      )

      // 1. Stake Amount ($)
      Text(
        text = "STAKE AMOUNT (USD)",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = TextSecondary
      )
      Spacer(modifier = Modifier.height(4.dp))

      OutlinedTextField(
        value = stakeText,
        onValueChange = { if (!isRunning) stakeText = it },
        enabled = !isRunning,
        leadingIcon = {
          Icon(
            imageVector = Icons.Default.LocalAtm,
            contentDescription = null,
            tint = GsquadYellow,
            modifier = Modifier.size(18.dp)
          )
        },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_stake_amount"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = GsquadYellow,
          unfocusedBorderColor = LightBorder,
          focusedContainerColor = Color(0xFFFAFAFA),
          unfocusedContainerColor = Color(0xFFFAFAFA)
        ),
        shape = RoundedCornerShape(10.dp)
      )

      // Quick Stake Chips
      if (!isRunning) {
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(1, 5, 10, 25, 50).forEach { amt ->
            val isSelected = stakeText == amt.toString()
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) GsquadYellow else Color(0xFFEFF2F6))
                .clickable { stakeText = amt.toString() }
                .padding(vertical = 6.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "$$amt",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) GsquadOnYellow else TextPrimary
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 2. Target Profit & Target Loss (Side-by-side)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Target Profit
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.TrendingUp,
              contentDescription = null,
              tint = TradeGreen,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "TARGET PROFIT",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = TradeGreen
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          OutlinedTextField(
            value = tpText,
            onValueChange = { if (!isRunning) tpText = it },
            enabled = !isRunning,
            prefix = { Text("$ ", fontWeight = FontWeight.Bold, color = TextPrimary) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_target_profit"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = TradeGreen,
              unfocusedBorderColor = LightBorder,
              focusedContainerColor = Color(0xFFFAFAFA),
              unfocusedContainerColor = Color(0xFFFAFAFA)
            ),
            shape = RoundedCornerShape(10.dp)
          )
        }

        // Target Loss (Stop Loss)
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Flag,
              contentDescription = null,
              tint = TradeRed,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "STOP LOSS",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = TradeRed
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          OutlinedTextField(
            value = slText,
            onValueChange = { if (!isRunning) slText = it },
            enabled = !isRunning,
            prefix = { Text("$ ", fontWeight = FontWeight.Bold, color = TextPrimary) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_target_loss"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = TradeRed,
              unfocusedBorderColor = LightBorder,
              focusedContainerColor = Color(0xFFFAFAFA),
              unfocusedContainerColor = Color(0xFFFAFAFA)
            ),
            shape = RoundedCornerShape(10.dp)
          )
        }
      }

      if (!isRunning) {
        Spacer(modifier = Modifier.height(14.dp))
        Button(
          onClick = {
            val stake = stakeText.toDoubleOrNull() ?: 5.0
            val tp = tpText.toDoubleOrNull() ?: 50.0
            val sl = slText.toDoubleOrNull() ?: 25.0
            onSaveRisk(stake, tp, sl)
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("save_risk_params_btn"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = GsquadYellow,
            contentColor = GsquadOnYellow
          )
        ) {
          Text(
            text = "Save Risk Settings",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.sp
          )
        }
      }
    }
  }
}
